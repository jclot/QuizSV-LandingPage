
// const {spawn} = require('child_process');
// const { writeFile } = require('fs');



//  // spawn new child process to call the python script
//  const python = spawn('python', ['../py/AppRunning.py']);
//  // collect data from script
//  python.stdout.on('data', function (data) {
//   console.log('Pipe data from python script ...');
//   console.log(data)
//  });

 
//  // in close event we are sure that stream is from child process is closed
//  python.on('close', function (code) {
//  console.log(`child process close all stdio with code ${code}`);

//  });
 

